localStorage.setItem("page_to_display",1);
localStorage.setItem("page_s_to_display",1);
localStorage.setItem("page_perf_to_display",1);
localStorage.setItem("page_perf_s_to_display",1);
localStorage.setItem("page_cart_to_display",1);